const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const methodOverride = require('method-override');

const app = express();
const PORT = 8000;
const Listing = require('./models/listing.js');

const MONGO_URL = "mongodb://127.0.0.1:27017/wanderlust";

const ejsMate = require('ejs-mate');

async function main() {
    try {
        await mongoose.connect(MONGO_URL);
        console.log('✅ Connected to MongoDB');
    } catch (err) {
        console.error('❌ Database connection failed:', err);
        process.exit(1);
    }
}
main();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json()); // Added to support JSON requests
app.use(methodOverride('_method'));
app.use(express.static('public'));
app.engine('ejs', ejsMate);
app.use(express.static(path.join(__dirname, "public"))); // Use this static files when dealing with everything else

app.get('/listings/new', (req, res) => {
    res.render('listings/new.ejs');
});

app.post('/listings', async (req, res) => {
    try {
        // Your logic to save the listing
        await Listing.create(req.body.listing);
        res.redirect('/listings/new');
    } catch (error) {
        res.status(400).send("Please fill in all required fields.");
    }
});

app.get('/listings', async (req, res) => {
    try {
        const allListings = await Listing.find({});
        console.log("Listings:", allListings); // Debugging statement
        res.render('listings/index.ejs', { allListings });
    } catch (err) {
        console.error('❌ Error retrieving listings:', err);
        res.status(500).send('Error fetching listings');
    }
});

app.get('/listings/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const listing = await Listing.findById(id);

        if (!listing) {
            return res.status(404).render('error.ejs', { message: 'Listing not found' });
        }

        res.render('listings/show.ejs', { listing });
    } catch (err) {
        console.error('❌ Error retrieving listing:', err);
        res.status(500).send('Error fetching listing');
    }
});

app.get('/listings/:id/edit', async (req, res) => {
    try {
        const { id } = req.params;
        const listing = await Listing.findById(id);

        if (!listing) {
            return res.status(404).render('error.ejs', { message: 'Listing not found' });
        }

        res.render('listings/edit.ejs', { listing });
    } catch (err) {
        console.error('❌ Error retrieving listing for edit:', err);
        res.status(500).send('Error fetching listing for edit');
    }
});

app.put('/listings/:id', async (req, res) => {
    try {
        const { id } = req.params;
        console.log("Updating listing with ID:", id); // Debugging
        console.log("Received update data:", req.body.listing); // Debugging

        const updatedListing = await Listing.findByIdAndUpdate(id, { ...req.body.listing }, { new: true });

        if (!updatedListing) {
            return res.status(404).send('Listing not found');
        }

        res.redirect(`/listings/${id}`);
    } catch (err) {
        console.error('❌ Error updating listing:', err);
        res.status(500).send('Error updating listing');
    }
});

// DELETE route
app.delete('/listings/:id', async (req, res) => {
    try {
        const { id } = req.params;
        await Listing.findByIdAndDelete(id);
        res.redirect('/listings');
    } catch (err) {
        console.error('❌ Error deleting listing:', err);
        res.status(500).send('Error deleting listing');
    }
});

// Testing route
app.get('/ok', (req, res) => {
    console.log('✅ Root route is working!');
    res.send('Root route is working!');
});

// Serve static images properly
app.use('/images', express.static(path.join(__dirname, 'public/images')));

app.listen(PORT, () => {
    console.log(`🚀 Server is running on port ${PORT}`);
});