// Example starter JavaScript for disabling form submissions if there are invalid fields
document.addEventListener("DOMContentLoaded", function () {
    var form = document.querySelector(".needs-validation");

    form.addEventListener("submit", function (event) {
        var inputs = document.querySelectorAll("input");

        inputs.forEach(function (input) {
            if (!input.value.trim()) {
                input.classList.add("is-invalid");
            } else {
                input.classList.remove("is-invalid");
            }
        });

        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }

        form.classList.add("was-validated");
    }, false);
});