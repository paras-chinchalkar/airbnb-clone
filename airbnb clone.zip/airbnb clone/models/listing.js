const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const listingSchema = new Schema({
    title: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        default: "No description provided"
    },
    image: {
        filename: { type: String, default: "default.jpg" },
        url: { type: String, default: "https://example.com/default.jpg" }
    },
    price: {
        type: Number,
        required: true,
        min: 0 // Ensures price is non-negative
    },
    location: String,
    country: String
});

const Listing = mongoose.model('Listing', listingSchema);
module.exports = Listing;